cd "$(dirname "$0")"
xattr -dr com.apple.quarantine *
./Archivos/VirtualMachine.app/Contents/MacOS/Squeak Archivos/Dialogo.image